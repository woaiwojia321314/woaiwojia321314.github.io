---
layout: pages
title: 域名信息查询
date: 2018-05-23 20:20:08
tags:
- 域名
---

你想知道网站域名的相关信息吗？其实很简单，跟谷哥或度娘说：whois，一大堆结果。在这里呢，就只给你推荐几个比较权威准确点的。
<!-- more -->

## 国外

免费用户有查询次数限制：[http://whois.domaintools.com/](http://whois.domaintools.com/)

## [](http://www.missfli.com/2016/09/07/domain-search-whois/#%E5%9B%BD%E5%86%85 "国内")国内

*   [威胁情报分析平台ThreatBook](https://x.threatbook.cn/)
*   [阿里云域名查询](https://whois.aliyun.com/)
*   [站长工具域名查询](http://whois.chinaz.com/)

**查询结果**

*   www.google.com ：208.111.59.15/19/23/27/29/30/34/38/42/44/45/49/53/57/59,93.46.8.89
*   www.microsoft.com ：118.215.11.168,182.215.11.168
*   www.apple.com/cn ：23.15.152.48,17.142.160.11,17.172.224.30,17.178.96.11
*   www.focebook.com ：31.13.79.220,179.60.192.3
*   www.twitter.com ：104.244.42.193/65
*   www.youtube.com ：74.125.200.136/190/91/93,216.58.211.46
*   www.philips.com ：118.215.81.147
*   www.linkedin.com ：103.20.94.1
*   www.amazon.com ：54.239.25.200,54.239.29.3
*   www.baidu.com ：14.215.177.37/38,103.235.46.212
*   www.alibaba.com ：205.204.101.42,110.75.112.20,140.205.94.148
*   www.qq.com ：101.226.103.106
