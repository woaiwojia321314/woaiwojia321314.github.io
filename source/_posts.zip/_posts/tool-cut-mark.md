---
layout: pages
title: 网页(UI)设计--切图标注工具
date: 2016-02-05 22:00:00
categories:
- tool
tags:
- ps
---

- [cutterman](http://www.cutterman.cn/v2/cutterman)(免费)--切图（ps 插件）
- [parker](http://www.cutterman.cn/v2/parker)(收费)--标注（ps 插件）
- [PxCook](http://www.fancynode.com.cn/pxcook/home)(免费)--标注
- [ASSISTOR PS](http://macdownload.informer.com/assistorps/)(免费)--切图，标注（ps 标注）
-  [BigShear](http://www.fancynode.com.cn/bigshear/home)(收费)--切图
-  [markman](http://getmarkman.com/)(收费)--标注

标注的工具试过几个。PxCook和markman功能类似，不足：没法准确取色，特别是带透明色；无法准确获取文字（字体，字体大小，字体颜色，行高）。parker功能都有，但是外边距只能量2个图层，无法多个图层一起标注外边距。ASSISTOR PS功能都有，但是内边距需要自己手动拉个选框出来，再选中2个图层，才能量了。

切图类工具呢，虽然没怎么试过，不过大家都推荐cutterman。
标注类工具呢，跟ps一起用的话，推荐ASSISTOR PS。单独用呢，用markman（mac版收费，windows有破解版，虽然官网说基本版免费，你用了就会发现啥叫基本功能了）和PxCook都行。

[免费了！切图标记外挂神器ASSISTOR PS深入解读（上）](http://www.uisdc.com/assistor-ps-introduction-1)
[免费了！切图标记外挂神器ASSISTOR PS深入解读（下）](http://www.uisdc.com/assistor-ps-introduction-2)
