
---
layout: pages
title: photoshop 前端网页查看的基本设置
date: 2018-05-29 16:40:00
categories:
- Photoshop
tags:
- Photoshop
---

前端开发用 photoshop 查看网页的一些基本设置。
<!-- more -->

### 新建
![新建.png](https://upload-images.jianshu.io/upload_images/1464420-d7f5c94979b0dc27.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

### 编辑
![编辑.png](https://upload-images.jianshu.io/upload_images/1464420-b1108e8477e5edf3.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

### 窗口
![窗口.png](https://upload-images.jianshu.io/upload_images/1464420-15217f8d8cbe7e93.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

### 工作区（存储窗口预设）
![窗口-存储一些设置.png](https://upload-images.jianshu.io/upload_images/1464420-658e3df7cd2165a4.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

### 视图
![视图.png](https://upload-images.jianshu.io/upload_images/1464420-bcec45b010c8a65d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

### 信息
![信息.png](https://upload-images.jianshu.io/upload_images/1464420-e5b7ada1773bb0b7.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

### 图层
![选中图层.png](https://upload-images.jianshu.io/upload_images/1464420-365437d32291c5b4.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

