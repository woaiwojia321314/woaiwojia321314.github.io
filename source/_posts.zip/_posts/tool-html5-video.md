---
layout: pages
title: html5视频转换工具
date: 2016-02-05 22:00:00
categories:
- tool
tags:
- html5
---

[10个免费的HTML5视频转换工具下载](http://sc.chinaz.com/info/140311417029.htm)，搜过一些工具，跟此文的工具都差不多。然后下载了好几款试用了一下，最后比较满意的是[any-video-converter](http://www.any-video-converter.com/products/mac_video_converter_freeware/)。其他的，我就简单说说使用情况吧。先提一句：html5的视频播放格式编码要求：h264/mp4, theora/ogg, vp8/webm。
1. Miro Video Converter 能转，但是转完后就不能用。
2. Miro Video Converter 这个比较悲剧，找半天都没找到转成webm格式的地方。
3. Freemake Video Converter 能转，也能用，但是具体参数比较少。
4. Easy HTML5 Video 能转，并且比any-video-converter转的视频大小还小些，看了一下，视频没有失真没有出入。但是他丫的居然在右上角有个水印，导致了没法商用。
5. any-video-converter 能转的格式不全，还是收费的。
6. Online-Convert.Com 具体编码参数基本没有，懒得试了。
7. any-video-converter 各种格式和参数比较齐全，pc端手机端平板端的都有。转完还有demo页面。
